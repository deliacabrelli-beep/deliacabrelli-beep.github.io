
# Sito personale – Delia Cabrelli
Stack: HTML + CSS (Bootstrap 5), nessun JS obbligatorio. Responsive con Grid/Flex, navbar sticky, favicon, Open Graph.
Pagine: /index.html (home), /cv.html (CV HTML), /contact.html (form).

## Pubblicazione GitHub Pages
1. Crea repo e carica i file alla root.
2. Settings → Pages → Deploy from branch (main / root).
3. Aggiorna i meta OG e l'URL assoluto quando online.
